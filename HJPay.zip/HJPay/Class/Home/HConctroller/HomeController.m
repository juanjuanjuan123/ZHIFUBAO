//
//  HomeController.m
//  HJPay
//
//  Created by ch－hj on 16/5/16.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import "HomeController.h"
#import "HomeCollectionViewCell.h"
#import "MorecollectionView.h"
#import "CircleView.h"

#define SECTION_FIRST  0
#define SECTION_SECOND  1
#define SECTION_THIRD 2

@interface HomeController ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>{
    UIView *view;
    NSArray *imageArr;
}
@property(nonatomic,strong) NSMutableArray *btnArr;
@property (nonatomic,strong) UICollectionView *collectionView;
@property (nonatomic,strong) UIScrollView *scrollView;
@property (nonatomic,strong) MorecollectionView *collectionMoreView;
@end

@implementation HomeController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupscrollerView];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    view = [[UIView alloc]initWithFrame:CGRectMake(0, self.navigationController.navigationBar.frame.size.height+20, self.view.frame.size.width,60)];
    view.backgroundColor = [UIColor blackColor];
    [view bringSubviewToFront:self.view];
    
   // [_scrollView addSubview:view];
   [self.view addSubview:view];
    [self setupView];
    [self setupCollection];
    [self setupCircleView];
    [self setupMoreView];
   
    
}

-(void)setupscrollerView{
     _scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
      _scrollView.scrollEnabled = YES;
    _scrollView.showsVerticalScrollIndicator = NO;
    _scrollView.showsHorizontalScrollIndicator = NO;
    //_scrollView.backgroundColor = [UIColor lightGrayColor];
    [self.view addSubview:_scrollView];
  
    _scrollView.contentSize = CGSizeMake(0 ,  self.view.frame.size.height);
    
}

-(void)setupView{
    UIImageView  *imageView;
    
    CGFloat w = self.view.frame.size.width/4;
    _btnArr = [NSMutableArray new];
    imageArr =[[NSArray alloc]initWithObjects:@"home_scan",@"home_scan",@"home_pay",@"home_scan", nil];
    
    for (int i=0; i<4; i++) {
        UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(w*i, 0, w, 60)];
        button.backgroundColor = [UIColor blackColor];
        [_btnArr addObject:button];
        button.tag = i;
        [view addSubview:_btnArr[i]];
    }
    
    
    for (UIButton *btn in _btnArr) {
        imageView = [UIImageView new];
        imageView.frame = CGRectMake((w-40)/2, 10, 40, 40);
        imageView.backgroundColor = [UIColor clearColor];
        
        for (int i=0; i<imageArr.count; i++) {
            if (btn.tag == i) {
                imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@",imageArr[i]]];
                imageView.tag=i;
                NSLog(@"imageview.tag%lu",imageView.tag);
                [btn addSubview:imageView];
                NSLog(@"image%@",imageArr[i]);

            }

        }
    }
    
}

-(void)setupCollection{
    UICollectionViewFlowLayout *flowLayout= [[UICollectionViewFlowLayout alloc]init];
    flowLayout.scrollDirection = UICollectionViewScrollDirectionVertical;
    _collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 60, self.view.frame.size.width,(self.view.frame.size.width-3)/4*3+3) collectionViewLayout:flowLayout];
    _collectionView.delegate = self;
    _collectionView.dataSource = self;
    _collectionView.backgroundColor = [UIColor lightGrayColor];
    
    //注册Cell，必须要有
    [_collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"UICollectionViewCell"];
    
    [_scrollView addSubview:_collectionView];
    //[self.view addSubview:_collectionView];
}

-(void)setupCircleView{
    CircleView *circleView = [[CircleView alloc]initWithFrame:CGRectMake(0, 60+_collectionView.frame.size.height, self.view.frame.size.width, 150)];
    [_scrollView addSubview:circleView];
    
    
}

-(void)setupMoreView{
    _collectionMoreView = [[MorecollectionView alloc]initWithFrame:CGRectMake(0, 60+_collectionView.frame.size.height+150 ,self.view.frame.size.width , (self.view.frame.size.width-3)/4*2+1)];
    //_collectionMoreView = [MorecollectionView new];
    [_collectionMoreView setBackgroundColor:[UIColor lightGrayColor]];
   // _collectionMoreView.frame = CGRectMake(0, self.navigationController.navigationBar.frame.size.height+80+_collectionView.frame.size.height ,self.view.frame.size.width , 200);
    
    [_scrollView addSubview:_collectionMoreView];
    

}

#pragma mark-collection代理方法实现
//定义展示每个section里的UICollectionViewCell的个数
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 4;
}

//定义展示的Section的个数
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 3;
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.section) {
        case SECTION_FIRST:
            return [self creatFirstSection:collectionView cellForItemAtIndexPath:indexPath];
            break;
        case SECTION_SECOND:
            return [self creatSecondSection:collectionView cellForItemAtIndexPath:indexPath];
            break;
            
        case SECTION_THIRD:
            return [self creatThirdSection:collectionView cellForItemAtIndexPath:indexPath];
            
        default:
            break;
    }
    return nil;
    
   }

-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    return YES;
    
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.section) {
        case SECTION_FIRST:
            [self action:indexPath];
            break;
        case SECTION_SECOND:
            [self actionForSecondSection:indexPath];
            break;
        case SECTION_THIRD:
            [self actionForThirdSection:indexPath];
            
        default:
            break;
    }
    
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    scrollView.contentSize = CGSizeMake(0, 0);

    
}
-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    
}
#pragma mark --UICollectionViewDelegateFlowLayout

////定义每个UICollectionView 纵向的间距
//- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
//{
//    return 10;
//}
//item间最小间距？？－hj
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    return 0;
}

//定义每个Item 的大小
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return CGSizeMake((self.view.frame.size.width-3)/4, (self.view.frame.size.width-3)/4);
}
//定义每个UICollectionView 的 margin
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(0, 0, 1, 0);
    
}


#pragma mark-privites
-(UICollectionViewCell *)creatFirstSection:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
//    static NSString * CellIdentifier = @"UICollectionViewCell";
//    HomeCollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
//    cell.backgroundColor =  [UIColor whiteColor];
//    if (!cell) {
//        cell = [[HomeCollectionViewCell alloc]init];
//    }
//    HomeModel *model = [HomeModel new];
//    if (indexPath.row == 0) {
//        model.string = @"淘宝";
//        model.imageName = @"i00";
//        cell.model = model;
//        return cell;
//    }else if (indexPath.row ==1){
//        model.string = @"生活缴费";
//        model.imageName = @"i01";
//        cell.model = model;
//        return cell;
//    }
//    else if (indexPath.row ==2){
//        model.string = @"教育缴费";
//        model.imageName = @"i02";
//        cell.model = model;
//        return cell;
//    }
//    else if (indexPath.row ==3){
//        model.string = @"红包";
//        model.imageName = @"i03";
//        cell.model = model;
//        return cell;
//    }
//    return nil;
    
    static NSString * CellIdentifier = @"UICollectionViewCell";
    UICollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
    cell.backgroundColor =  [UIColor whiteColor];
    for (id subView in cell.contentView.subviews) {
        [subView removeFromSuperview];
    }
    
    
      NSArray *arr = @[@"淘宝",@"生活缴费",@"教育缴费",@"红包"];
    UIView *view1 = [[UIView alloc]initWithFrame:CGRectMake(0, 0, (self.view.frame.size.width-3)/4,(self.view.frame.size.width-3)/4 )];
    view1.backgroundColor = [UIColor whiteColor];
    [cell.contentView addSubview:view1];
    
    UILabel *namelabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 60,  view1.frame.size.width,20)];
    namelabel.textColor = [UIColor blackColor];
    namelabel.font=[UIFont systemFontOfSize:12];
    //    namelabel.backgroundColor = [UIColor orangeColor];
    namelabel.text = [NSString stringWithFormat:@"%@",arr[(long)indexPath.row]];
    namelabel.textAlignment = NSTextAlignmentCenter;
    namelabel.lineBreakMode = UILineBreakModeWordWrap;
    namelabel.numberOfLines = 0;
    
    
    [view1 addSubview:namelabel];
    
    
    
    
    UIImageView  * TPimageView=[[UIImageView alloc] initWithFrame:CGRectMake((view1.frame.size.width-30)/2,20, 30, 30 )];
    TPimageView.backgroundColor = [UIColor whiteColor];
    //    TPimageView.layer.cornerRadius = 20;
    //    TPimageView.layer.masksToBounds = YES;
    [TPimageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"i0%ld",(long)indexPath.row]]];
    [view1 addSubview:TPimageView];
    
    return cell;
    


}

-(UICollectionViewCell *)creatSecondSection:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
//    static NSString * CellIdentifier = @"UICollectionViewSecondCell";
//    HomeCollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
//    cell.backgroundColor =  [UIColor whiteColor];
//    if (!cell) {
//        cell = [[HomeCollectionViewCell alloc]init];
//    }
//    HomeModel *model = [HomeModel new];
//    if (indexPath.row == 0) {
//        model.string = @"物流";
//        model.imageName = @"i04";
//        cell.model = model;
//        return cell;
//    }else if (indexPath.row ==1){
//        model.string = @"信用卡";
//        model.imageName = @"i05";
//        cell.model = model;
//        return cell;
//    }
//    else if (indexPath.row ==2){
//        model.string = @"转账";
//        model.imageName = @"i06";
//        cell.model = model;
//        return cell;
//    }
//    else if (indexPath.row ==3){
//        model.string = @"爱心捐款";
//        model.imageName = @"i07";
//        cell.model = model;
//        return cell;
//    }
//    return nil;
    static NSString * CellIdentifier = @"UICollectionViewCell";
    UICollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
    cell.backgroundColor =  [UIColor whiteColor];
    for (id subView in cell.contentView.subviews) {
        [subView removeFromSuperview];
    }
    
    
      NSArray *arr = @[@"物流",@"信用卡",@"转账",@"爱心捐款"];
    UIView *view1 = [[UIView alloc]initWithFrame:CGRectMake(0, 0, (self.view.frame.size.width-3)/4,(self.view.frame.size.width-3)/4 )];
    view1.backgroundColor = [UIColor whiteColor];
    [cell.contentView addSubview:view1];
    
    UILabel *namelabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 60,  view1.frame.size.width,20)];
    namelabel.textColor = [UIColor blackColor];
    namelabel.font=[UIFont systemFontOfSize:12];
    //    namelabel.backgroundColor = [UIColor orangeColor];
    
   
    namelabel.text = [NSString stringWithFormat:@"%@",arr[(long)indexPath.row]];
    namelabel.textAlignment = NSTextAlignmentCenter;
    namelabel.lineBreakMode = UILineBreakModeWordWrap;
    namelabel.numberOfLines = 0;
    
    
    [view1 addSubview:namelabel];
    
    
    
    
    UIImageView  * TPimageView=[[UIImageView alloc] initWithFrame:CGRectMake((view1.frame.size.width-30)/2,20, 30, 30 )];
    TPimageView.backgroundColor = [UIColor whiteColor];
    //    TPimageView.layer.cornerRadius = 20;
    //    TPimageView.layer.masksToBounds = YES;
    [ TPimageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"i0%ld",(long)indexPath.row+4]]];
    [view1 addSubview: TPimageView];
    
    return cell;
    


}

-(UICollectionViewCell *)creatThirdSection:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
//    static NSString * CellIdentifier = @"UICollectionViewThirdCell";
//    HomeCollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
//    cell.backgroundColor =  [UIColor whiteColor];
//    if (!cell) {
//        cell = [[HomeCollectionViewCell alloc]init];
//    }
//    HomeModel *model = [HomeModel new];
//    if (indexPath.row == 0) {
//        model.string = @"彩票";
//        model.imageName = @"i08";
//        cell.model = model;
//        return cell;
//    }else if (indexPath.row ==1){
//        model.string = @"当面付";
//        model.imageName = @"i09";
//        cell.model = model;
//        return cell;
//    }
//    else if (indexPath.row ==2){
//        model.string = @"余额宝";
//        model.imageName = @"i10";
//        cell.model = model;
//        return cell;
//    }
//    else if (indexPath.row ==3){
//        model.string = @"AA付款";
//        model.imageName = @"i11";
//        cell.model = model;
//        return cell;
//    }
//    return nil;
//    

    static NSString * CellIdentifier = @"UICollectionViewCell";
    UICollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
    cell.backgroundColor =  [UIColor whiteColor];
    for (id subView in cell.contentView.subviews) {
        [subView removeFromSuperview];
    }
    
    UIView *view1 = [[UIView alloc]initWithFrame:CGRectMake(0, 0, (self.view.frame.size.width-3)/4,(self.view.frame.size.width-3)/4 )];
    view1.backgroundColor = [UIColor whiteColor];
    [cell.contentView addSubview:view1];
    
    NSArray *arr = @[@"彩票",@"当面付",@"余额宝",@"AA付款"];
    UILabel *namelabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 60,  view1.frame.size.width,20)];
    namelabel.textColor = [UIColor blackColor];
    namelabel.font=[UIFont systemFontOfSize:12];
    //    namelabel.backgroundColor = [UIColor orangeColor];
    namelabel.text = [NSString stringWithFormat:@"%@",arr[(long)indexPath.row]];
    namelabel.textAlignment = NSTextAlignmentCenter;
    namelabel.lineBreakMode = UILineBreakModeWordWrap;
    namelabel.numberOfLines = 0;
    
    
    [view1 addSubview:namelabel];
    
    
    
    
    UIImageView  * TPimageView=[[UIImageView alloc] initWithFrame:CGRectMake((view1.frame.size.width-30)/2,20, 30, 30 )];
    TPimageView.backgroundColor = [UIColor whiteColor];
    //    TPimageView.layer.cornerRadius = 20;
    //    TPimageView.layer.masksToBounds = YES;
    if ((long)indexPath.row+8<10) {
        [ TPimageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"i0%ld",(long)indexPath.row+8]]];
    }else{
        [ TPimageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"i1%ld",(long)indexPath.row]]];
    }
    
    [view1 addSubview: TPimageView];
    
    return cell;

}

-(void)action:(NSIndexPath *)indexPath{
    if (indexPath.row==0) {
        UITableViewController *tabVc = [UITableViewController new];
        [self.navigationController pushViewController:tabVc animated:NO];
    }
    else  if (indexPath.row==1) {
        UITableViewController *tabVc = [UITableViewController new];
        [self.navigationController pushViewController:tabVc animated:NO];
    }
    else  if (indexPath.row==2) {
        UITableViewController *tabVc = [UITableViewController new];
        [self.navigationController pushViewController:tabVc animated:NO];
    }else{
        UITableViewController *tabVc = [UITableViewController new];
        [self.navigationController pushViewController:tabVc animated:NO];
    }

}

-(void)actionForSecondSection:(NSIndexPath *)indexPath{
    if (indexPath.row==0) {
        UITableViewController *tabVc = [UITableViewController new];
        [self.navigationController pushViewController:tabVc animated:NO];
    }
    else  if (indexPath.row==1) {
        UITableViewController *tabVc = [UITableViewController new];
        [self.navigationController pushViewController:tabVc animated:NO];
    }
    else  if (indexPath.row==2) {
        UITableViewController *tabVc = [UITableViewController new];
        [self.navigationController pushViewController:tabVc animated:NO];
    }else{
        UITableViewController *tabVc = [UITableViewController new];
        [self.navigationController pushViewController:tabVc animated:NO];
    }

}

-(void)actionForThirdSection:(NSIndexPath *)indexPath{
    if (indexPath.row==0) {
        UITableViewController *tabVc = [UITableViewController new];
        [self.navigationController pushViewController:tabVc animated:NO];
    }
    else  if (indexPath.row==1) {
        UITableViewController *tabVc = [UITableViewController new];
        [self.navigationController pushViewController:tabVc animated:NO];
    }
    else  if (indexPath.row==2) {
        UITableViewController *tabVc = [UITableViewController new];
        [self.navigationController pushViewController:tabVc animated:NO];
    }else{
        UITableViewController *tabVc = [UITableViewController new];
        [self.navigationController pushViewController:tabVc animated:NO];
    }
    

    
}
@end
