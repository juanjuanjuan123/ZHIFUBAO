//
//  HomeModel.m
//  HJPay
//
//  Created by ch－hj on 16/5/18.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import "HomeModel.h"

@implementation HomeModel


@end
