//
//  CircleView.h
//  HJPay
//
//  Created by ch－hj on 16/5/19.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CircleView : UIView
@property(nonatomic,strong) NSArray *imageArr;
@end
