//
//  HomeCollectionViewCell.h
//  HJPay
//
//  Created by ch－hj on 16/5/18.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeModel.h"

@interface HomeCollectionViewCell : UICollectionViewCell
@property (nonatomic,strong) HomeModel *model;
@property (nonatomic,strong) UILabel *nameLabel;
@property (nonatomic,strong) UIImageView *iconImageView;

@end
