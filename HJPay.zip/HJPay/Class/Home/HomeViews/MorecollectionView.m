//
//  MorecollectionView.m
//  HJPay
//
//  Created by ch－hj on 16/5/18.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import "MorecollectionView.h"

#define SECTION_FIRST  0
#define SECTION_SECOND 1
@interface MorecollectionView()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>{
}
@property (nonatomic,strong) UICollectionView *collectionMoreView;
@end

@implementation MorecollectionView

- (instancetype) initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self setupCollectionView];
        self.frame =frame;
    }
    return self;
}

-(void)setupCollectionView{
    UICollectionViewFlowLayout *flowLayout= [[UICollectionViewFlowLayout alloc]init];
    flowLayout.scrollDirection = UICollectionViewScrollDirectionVertical;
    _collectionMoreView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height) collectionViewLayout:flowLayout];
    _collectionMoreView.delegate = self;
    _collectionMoreView.dataSource = self;
    [_collectionMoreView setBackgroundColor:[UIColor lightGrayColor]];
    
    //注册Cell，必须要有
    [_collectionMoreView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"UICollectionViewCell"];
    [self addSubview:_collectionMoreView];

    
}


#pragma mark-collection代理方法实现
//定义展示每个section里的UICollectionViewCell的个数
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 4;
}

//定义展示的Section的个数
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 2;
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.section) {
        case SECTION_FIRST:
            return [self creatFirstSection:collectionView cellForItemAtIndexPath:indexPath];
            break;
        case SECTION_SECOND:
            return [self creatSecondSection:collectionView cellForItemAtIndexPath:indexPath];
           
            
        default:
            break;
    }
    return nil;
    
}
#pragma mark-UICollectionViewDelegateFlowLayout代理方法
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    return 0;
}

//定义每个Item 的大小
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return CGSizeMake((self.frame.size.width-3)/4, (self.frame.size.width-3)/4);
}
//定义每个UICollectionView 的 margin
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(0, 0, 1, 0);
    
}



#pragma mark-private
-(UICollectionViewCell *)creatFirstSection:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
       static NSString * CellIdentifier = @"UICollectionViewCell";
    UICollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
    cell.backgroundColor =  [UIColor whiteColor];
    for (id subView in cell.contentView.subviews) {
        [subView removeFromSuperview];
    }
    
    NSArray *arr = @[@"淘宝",@"生活缴费",@"教育缴费",@"红包"];
    UIView *view1 = [[UIView alloc]initWithFrame:CGRectMake(0, 0, (self.frame.size.width-3)/4,(self.frame.size.width-3)/4 )];
    view1.backgroundColor = [UIColor whiteColor];
    [cell.contentView addSubview:view1];
    
    UILabel *namelabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 60,  view1.frame.size.width,20)];
    namelabel.textColor = [UIColor blackColor];
    namelabel.font=[UIFont systemFontOfSize:12];
    //    namelabel.backgroundColor = [UIColor orangeColor];
    namelabel.text = [NSString stringWithFormat:@"%@",arr[(long)indexPath.row]];
    namelabel.textAlignment = NSTextAlignmentCenter;
    namelabel.lineBreakMode = UILineBreakModeWordWrap;
    namelabel.numberOfLines = 0;
    
    
    [view1 addSubview:namelabel];
    
    
    
    
    UIImageView  * TPimageView=[[UIImageView alloc] initWithFrame:CGRectMake((view1.frame.size.width-30)/2,20, 30, 30 )];
    TPimageView.backgroundColor = [UIColor whiteColor];
    //    TPimageView.layer.cornerRadius = 20;
    //    TPimageView.layer.masksToBounds = YES;
    [TPimageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"i0%ld",(long)indexPath.row]]];
    [view1 addSubview:TPimageView];
    
    return cell;
    
}


-(UICollectionViewCell *)creatSecondSection:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
        static NSString * CellIdentifier = @"UICollectionViewCell";
    UICollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
    cell.backgroundColor =  [UIColor whiteColor];
    for (id subView in cell.contentView.subviews) {
        [subView removeFromSuperview];
    }
    
    
    NSArray *arr = @[@"物流",@"信用卡",@"转账",@"爱心捐款"];
    UIView *view1 = [[UIView alloc]initWithFrame:CGRectMake(0, 0, (self.frame.size.width-3)/4,(self.frame.size.width-3)/4 )];
    view1.backgroundColor = [UIColor whiteColor];
    [cell.contentView addSubview:view1];
    
    UILabel *namelabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 60,  view1.frame.size.width,20)];
    namelabel.textColor = [UIColor blackColor];
    namelabel.font=[UIFont systemFontOfSize:12];
    //    namelabel.backgroundColor = [UIColor orangeColor];
    
    
    namelabel.text = [NSString stringWithFormat:@"%@",arr[(long)indexPath.row]];
    namelabel.textAlignment = NSTextAlignmentCenter;
    namelabel.lineBreakMode = UILineBreakModeWordWrap;
    namelabel.numberOfLines = 0;
    
    [view1 addSubview:namelabel];
    
    
    
    
    UIImageView  * TPimageView=[[UIImageView alloc] initWithFrame:CGRectMake((view1.frame.size.width-30)/2,20, 30, 30 )];
    TPimageView.backgroundColor = [UIColor whiteColor];
    //    TPimageView.layer.cornerRadius = 20;
    //    TPimageView.layer.masksToBounds = YES;
    [ TPimageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"i0%ld",(long)indexPath.row+4]]];
    [view1 addSubview: TPimageView];
    
    return cell;
    
    
    
}



@end
