//
//  HomeCollectionViewCell.m
//  HJPay
//
//  Created by ch－hj on 16/5/18.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import "HomeCollectionViewCell.h"

@implementation HomeCollectionViewCell
-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self setupColletionViewCell];
    }
    return self;
}

-(void)setupColletionViewCell{
    _iconImageView = [UIImageView new];
    _nameLabel = [UILabel new];
    
    _iconImageView.frame = CGRectMake(0, 10, 20, 20);
    
    
    _nameLabel.textColor = [UIColor blackColor];
    _nameLabel.font = [UIFont systemFontOfSize:15];
    _nameLabel.frame = CGRectMake(0, 40, 20, 20);
    _nameLabel.textAlignment =NSTextAlignmentCenter;
    
    
    
    [self.contentView addSubview:_iconImageView];
    [self.contentView addSubview:_nameLabel];
}

-(void)setModel:(HomeModel *)model{
    _model = model;
    _iconImageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@",model.imageName]];
    _nameLabel.text = [NSString stringWithFormat:@"%@",model.string];
}



@end
