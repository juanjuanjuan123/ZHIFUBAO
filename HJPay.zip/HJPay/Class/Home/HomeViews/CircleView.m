//
//  CircleView.m
//  HJPay
//
//  Created by ch－hj on 16/5/19.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import "CircleView.h"
@interface CircleView()<UIScrollViewDelegate>{
}
@property (nonatomic,strong) UIScrollView *scroller;
@property (nonatomic,strong) UIPageControl *pagecontrol;
@property (nonatomic,strong) NSTimer *timer;
@end


@implementation CircleView

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self setupScrollerView];
        [self setPageControl];
    }
    return self;
}

-(void)setupScrollerView{
    _scroller = [[UIScrollView alloc]init];
    CGFloat scrollerW = [UIScreen mainScreen].bounds.size.width;
    CGFloat scrollerH = self.frame.size.height;
    _scroller.frame = CGRectMake(0, 0, scrollerW, scrollerH);
    _scroller.delegate = self;
    for (int i=0;i<5;i++){
        UIImageView *imageView = [[UIImageView alloc]init];
         CGFloat imageX = scrollerW * (i + 1);
        imageView.frame = CGRectMake(imageX, 0, scrollerW, scrollerH);
        UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"img_%02d",i+1]];
        imageView.image = image;
        [_scroller addSubview:imageView];
    }
    
    UIImageView *firstImageview = [[UIImageView alloc]init];
    firstImageview.frame = CGRectMake(0, 0,scrollerW,scrollerH);
    firstImageview.image = [UIImage imageNamed:[NSString stringWithFormat:@"img_05"]];
    [_scroller addSubview:firstImageview];
    _scroller.contentOffset = CGPointMake(scrollerW, 0);
    
    UIImageView *lastImageView = [[UIImageView alloc]init];
    lastImageView.frame = CGRectMake(scrollerW*6, 0, scrollerW, scrollerH);
    lastImageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"img_01"]];
     _scroller.contentSize = CGSizeMake((5 + 2) * scrollerW, 0);
    [_scroller addSubview:lastImageView];
    [self addSubview:_scroller];
    [self addTimer];

}

-(void)setPageControl{
    _pagecontrol = [[UIPageControl alloc]init];
    CGFloat width = [UIScreen mainScreen].bounds.size.width;
    CGFloat pageW = 100;
    _pagecontrol.frame =CGRectMake((width - pageW) * 0.5, 140, pageW, 4);
    _pagecontrol.numberOfPages = 5;
    _pagecontrol.currentPageIndicatorTintColor = [UIColor redColor];
    _pagecontrol.pageIndicatorTintColor = [UIColor lightGrayColor];
    _pagecontrol.currentPage = 0;
    [self addSubview:_pagecontrol];
   
}
- (void)addTimer{
    self.timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(nextImage) userInfo:nil repeats:YES];
    NSRunLoop *runLoop = [NSRunLoop currentRunLoop];
    [runLoop addTimer:self.timer forMode:NSRunLoopCommonModes];
}

-(void)nextImage {
    CGFloat width = self.scroller.frame.size.width;
    NSInteger index = self.pagecontrol.currentPage;
    if (index == 5 + 1) {
        index = 0;
    } else {
        index++;
    }
    [self.scroller setContentOffset:CGPointMake((index + 1) * width, 0)animated:YES];
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    CGFloat width = self.scroller.frame.size.width;
    int index = (self.scroller.contentOffset.x + width * 0.5) / width;
    if (index == 5 + 2) {
        index = 1;
    } else if(index == 0) {
        index = 5;
    }
    self.pagecontrol.currentPage = index - 1;
}

-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    [self.timer invalidate];
    self.timer = nil;
}

-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    [self addTimer];
}

-(void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView{
    [self scrollViewDidEndDecelerating:scrollView];
}

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    CGFloat width = self.scroller.frame.size.width;
    int index = (self.scroller.contentOffset.x + width * 0.5) / width;
    if (index == 5 + 1) {
        [self.scroller setContentOffset:CGPointMake(width, 0) animated:NO];
    } else if (index == 0) {
        [self.scroller setContentOffset:CGPointMake(5 * width, 0) animated:NO];
    }
}

@end
