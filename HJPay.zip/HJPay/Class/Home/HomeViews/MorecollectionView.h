//
//  MorecollectionView.h
//  HJPay
//
//  Created by ch－hj on 16/5/18.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MorecollectionView : UIView

@end
