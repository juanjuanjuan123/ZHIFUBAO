//
//  ServiceTableViewCell.h
//  HJPay
//
//  Created by ch－hj on 16/5/25.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ServiceModel.h"

@interface ServiceTableViewCell : UITableViewCell
@property(nonatomic,strong) UIImageView *iconImageView;
@property (nonatomic,strong) UILabel *nameLabel;
@property (nonatomic,strong) UILabel *detailLabel;
@property (nonatomic,strong) ServiceModel *model;


@end
