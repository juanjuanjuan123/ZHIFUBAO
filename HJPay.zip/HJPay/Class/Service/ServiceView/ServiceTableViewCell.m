//
//  ServiceTableViewCell.m
//  HJPay
//
//  Created by ch－hj on 16/5/25.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import "ServiceTableViewCell.h"

@implementation ServiceTableViewCell

-(instancetype) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self setupCell];
    }
    return self;
}

-(void)setupCell{
    _nameLabel = [UILabel new];
    _detailLabel = [UILabel new];
    _iconImageView = [UIImageView new];
    
    _nameLabel.textColor = [UIColor blackColor];
    _nameLabel.font = [UIFont boldSystemFontOfSize:16];
    
    _detailLabel.textColor = [UIColor lightGrayColor];
    _detailLabel.font = [UIFont systemFontOfSize:14];
    
    [self.contentView addSubview:_nameLabel];
    [self.contentView addSubview:_detailLabel];
    [self.contentView addSubview:_iconImageView];
    
    _iconImageView.frame = CGRectMake(15, (60-50)/2, 50, 50);
    _nameLabel.frame =  CGRectMake(80, 10, 150, 20);
    _detailLabel.frame =  CGRectMake(80, 30, 150, 20);
    
    
}

-(void)setModel:(ServiceModel *)model{
    _model = model;
    _iconImageView.image= [UIImage imageNamed:model.imageName];
    _nameLabel.text = [NSString stringWithFormat:@"%@",model.name];
    _detailLabel.text = [NSString stringWithFormat:@"%@",model.detailMsg];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
