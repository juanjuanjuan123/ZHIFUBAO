//
//  ServiceModel.m
//  HJPay
//
//  Created by ch－hj on 16/5/25.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import "ServiceModel.h"

@implementation ServiceModel

@end
