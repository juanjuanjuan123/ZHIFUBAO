//
//  Random.m
//  HJPay
//
//  Created by ch－hj on 16/5/25.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import "Random.h"
@interface Random(){
  
}

@end

@implementation Random
NSArray *nameArr;
NSArray *detailArr;
NSArray *imageArr;

+(NSArray *)nameArr{
    if (!nameArr) {
        nameArr = [NSArray new];
        nameArr = @[@"晴天",@"小浣熊",@"我没有名字",@"名字怪怪",@"西门吹雪",@"我是大帅哥",@"一枝独梅",@"寒风凌烈",@"睡不醒",@"呼啦啦",@"天天乐",@"那年的等待",@"莫名其妙",@"闹钟",@"开关",@"wohjl",@"yunkih",@"kslanfgd"];
    }
    return nameArr;
}

+(NSArray *)detailArr{
    if (!detailArr) {
        detailArr = [NSArray new];
        detailArr = @[@"晴天：你好",@"小浣熊：不好",@"小浣熊：今天天气不错🐂🐂🐂🐂",@"我没有名字：一团乌云",@"名字怪怪：谁要请我吃大餐",@"呼啦啦：不懂",@"kslanfgd：哪耍起",@"yunkih：yunyunyunyun",@"开关：请叫我0和1",@"睡不醒:点菜点菜",@"寒风凌烈：好大的雪",@"一枝独梅：哥不信",@"我是大帅哥：麻将麻将，约起，🐎🐎🐎",@"闹钟：二锅头，二锅头",@"那年的等待：不服不服，不服就来喔的微店😊😊",@"莫名其妙：莫名其妙莫名其妙莫名其妙莫名其妙🐱🐱🐱🐱",@"wohjl；吃西瓜吃西瓜",@"晴天：有意思吗，没意思",@"寒风凌烈：讨厌下雨天，还要去上班",@"呼啦啦：下雨☔️收衣服",@"天天乐：最喜欢消消乐😊😊😊",@"我是大帅哥：谁有我帅🐎🐎🐎",@"名字怪怪：你🐎说🐎啥🐎呢",@"西门吹雪：一剑削死你",@"kslanfgd：有木有人儿？",@"那年的等待：坑死我了。。。。。",@"一枝独梅：什么事？🐂🐂🐂🐂"];
    }
    return detailArr;
}


+(NSArray *)imageArr{
    if (!imageArr) {
        imageArr =[NSArray new];
        NSMutableArray *arr = [NSMutableArray new];
        for (int i=1; i<15; i++) {
            NSString *string = [NSString stringWithFormat:@"ooopic_%d.png",i];
            [arr addObject:string];
        }
        imageArr = [arr copy];
    }
    return imageArr;
}

+(NSString *)iconImageString{
    int randomindex = arc4random_uniform((int)[self imageArr].count);
    return imageArr[randomindex];
}
+(NSString *)nameString{
     int randomindex = arc4random_uniform((int)[self nameArr].count);
    return nameArr[randomindex];
}
+(NSString *)detailString{
     int randomindex = arc4random_uniform((int)[self detailArr].count);
    return detailArr[randomindex];
}
@end
