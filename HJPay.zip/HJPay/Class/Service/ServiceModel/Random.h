//
//  Random.h
//  HJPay
//
//  Created by ch－hj on 16/5/25.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Random : NSObject
+(NSString *)iconImageString;
+(NSString *)nameString;
+(NSString *)detailString;
@end
