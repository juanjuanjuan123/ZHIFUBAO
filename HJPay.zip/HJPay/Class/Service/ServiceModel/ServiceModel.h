//
//  ServiceModel.h
//  HJPay
//
//  Created by ch－hj on 16/5/25.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ServiceModel : NSObject
@property(nonatomic,strong) NSString *name;
@property (nonatomic,strong) NSString *detailMsg;
@property (nonatomic,strong) NSString *imageName;

@end
