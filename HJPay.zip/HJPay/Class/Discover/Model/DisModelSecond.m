//
//  DisModelSecond.m
//  HJPay
//
//  Created by ch－hj on 16/5/16.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import "DisModelSecond.h"

@implementation DisModelSecond
- (id)init{
    self = [super init];
    if (self) {
        _imageNameArr = [NSArray new];
        _stringNameArr = [NSArray new];
    }
    return self;
}
@end
