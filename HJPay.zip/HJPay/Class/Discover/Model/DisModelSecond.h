//
//  DisModelSecond.h
//  HJPay
//
//  Created by ch－hj on 16/5/16.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DisModelSecond : NSObject
@property (nonatomic,strong) NSArray *imageNameArr;
@property (nonatomic,strong) NSArray *stringNameArr;
@end
