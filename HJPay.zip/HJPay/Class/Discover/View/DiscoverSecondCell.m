//
//  DiscoverSecondCell.m
//  HJPay
//
//  Created by ch－hj on 16/5/16.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import "DiscoverSecondCell.h"

@implementation DiscoverSecondCell

- (instancetype) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self setupView];
        self.accessoryType =UITableViewCellAccessoryDisclosureIndicator;
    }
    return self;
}

- (void)setFrame:(CGRect)frame
{
    frame.size.height -= 1;
    frame.size.width = self.frame.size.width;
    [super setFrame:frame];
    
}
- (void)setupView{
    _iconImage = [UIImageView new];
    _nameLabel = [UILabel new];
    _nameLabel.textColor = [UIColor blackColor];
    _nameLabel.font = [UIFont systemFontOfSize:15];
    
    [self.contentView addSubview:_iconImage];
    [self.contentView addSubview:_nameLabel];
    
    _iconImage.frame = CGRectMake(15, (43-25)/2, 25, 25);
    _nameLabel.frame =  CGRectMake(50, (43-21)/2, 150, 21);


}

- (void)setModel:(DiscoverModel *)model
{
    _model = model;
    
    _nameLabel.text = [NSString stringWithFormat:@"%@",model.string];
    _iconImage.image = [UIImage imageNamed:model.imageName];
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}



@end
