//
//  DiscoverSecondCell.h
//  HJPay
//
//  Created by ch－hj on 16/5/16.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DiscoverModel.h"

@interface DiscoverSecondCell : UITableViewCell
@property (nonatomic,strong)DiscoverModel *model;
@property (nonatomic,strong)UIImageView *iconImage;
@property (nonatomic,strong) UILabel *nameLabel;

@end
