//
//  DiscoverOneCell.m
//  HJPay
//
//  Created by ch－hj on 16/5/16.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import "DiscoverOneCell.h"

@implementation DiscoverOneCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        [self setupView];
        
    }
    return self;
}
- (void)setFrame:(CGRect)frame
{
    frame.size.height -= 1;
    frame.size.width = [UIScreen mainScreen].bounds.size.width;
    
    [super setFrame:frame];
    
}
- (void)setupView{
    _imageArr = [NSMutableArray new];
    _iconImage = [UIImageView new];
    _nameLabel = [UILabel new];
    _stringArr = [NSMutableArray new];
    CGFloat margin = 30;
    UIView *view = [UIView new];
    view.frame = self.bounds;
    [self.contentView addSubview:view];
    
    CGFloat W = ([UIScreen mainScreen].bounds.size.width-margin*5)/4;
    CGFloat H = W;
    for (int i = 0; i< 4; i++) {
        UIImageView *imageview= [UIImageView new];
        imageview.frame = CGRectMake(W*i+margin*(i+1), 5, W, H);
        [_imageArr addObject:imageview];
        imageview.tag =i;
        [imageview setBackgroundColor:[UIColor whiteColor]];
        [self.contentView addSubview:_imageArr[i]];
    }
    for (UIImageView *view in _imageArr) {
        for (int i=0; i<_imageArr.count; i++) {
            if (view.tag ==i) {
                _iconImage = _imageArr[i];
              
                 NSLog(@"hhhhh%f",_iconImage.frame.origin.x);
                
            }
        }
    }
    
    CGFloat H1 = 25;
    for (int i = 0; i< 4; i++) {
        UILabel *lab = [UILabel new];
        lab.frame = CGRectMake(W*i+margin*(i+1), W+10, W, H1);
        lab.textColor = [UIColor blackColor];
        lab.font = [UIFont boldSystemFontOfSize:16];
        lab.textAlignment = NSTextAlignmentCenter;

        lab.tag =i;
        [_stringArr addObject:lab];
        [self.contentView addSubview:_stringArr[i]];
    }
    
    for (UILabel *label in _stringArr) {
        for (int i=0; i<_stringArr.count; i++) {
            if (label.tag ==i) {
                _nameLabel = _stringArr[i];
                
                NSLog(@"xxxxnamelabel%f",_nameLabel.frame.origin.x);
                
            }
        }
    }

    
    
}

-(void) setModel:(DisModelSecond *)model{
    _model = model;
    NSMutableArray *mutArr = [NSMutableArray new];
    NSMutableArray *labelArr = [NSMutableArray new];
   for (NSString *imageName in model.imageNameArr) {
        UIImage *image = [UIImage new];
        image = [UIImage imageNamed:imageName];
       [mutArr addObject:image];
    }
    for (int i=0; i<mutArr.count; i++) {
        for (UIImageView *view in _imageArr ) {
            if (view.tag==i) {
            view.image =mutArr[i];
            }
        }

    }
    
   for (NSString *string in model.stringNameArr) {
        UILabel *label = [[UILabel alloc]init];
        label.text = string;
        [labelArr addObject:label.text];
    }
    for (int i=0; i<labelArr.count; i++) {
        for (UILabel *label2  in _stringArr ) {
            if (label2.tag==i) {
                label2.text = labelArr[i];
               
            }
        }
        
    }
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}



@end
