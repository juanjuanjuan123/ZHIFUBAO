//
//  DiscoverOneCell.h
//  HJPay
//
//  Created by ch－hj on 16/5/16.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DisModelSecond.h"

@interface DiscoverOneCell : UITableViewCell
@property (nonatomic,strong) DisModelSecond  *model;
@property (nonatomic,strong) UIImageView *iconImage;
@property (nonatomic,strong) UILabel *nameLabel;
@property (nonatomic,strong) NSMutableArray *imageArr;
@property (nonatomic,strong) NSMutableArray *stringArr;


@end
