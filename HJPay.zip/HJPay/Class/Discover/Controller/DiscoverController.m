//
//  DiscoverController.m
//  HJPay
//
//  Created by ch－hj on 16/5/16.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import "DiscoverController.h"
#import "DiscoverOneCell.h"
#import "DiscoverSecondCell.h"

#define    SECTION_FIRST  0
#define    SECTION_SECOND 1
#define    SECTION_THREE  2


@interface DiscoverController ()
@property (nonatomic,strong) NSArray *imageNameArr;
@property (nonatomic,strong) NSArray *stringNameArr;

@end

@implementation DiscoverController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    self.tableView.separatorColor = [UIColor lightGrayColor];

    [self setUpTableView];
    
    
}

- (void) setUpTableView{
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    switch (section) {
        case SECTION_FIRST:
            return 1;
            break;
            case SECTION_SECOND:
            return 3;
            break;
            case SECTION_THREE:
            return 1;

        default:
            break;
    }

    return 0;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.section) {
        case SECTION_FIRST:
          return [self createFirstSection:tableView cellForRowAtIndexPath:indexPath];
          
            break;
            case SECTION_SECOND:
            return [self createSecondSection:tableView cellForRowAtIndexPath:indexPath];
            break;
            case SECTION_THREE:
            return [self createThreeSection:tableView cellForRowAtIndexPath:indexPath];
        default:
            break;
    }
    return nil;

}

- (UITableViewCell *)createFirstSection:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"firstcell";
    DiscoverOneCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier ];
    [cell removeFromSuperview];
    if (!cell) {
        cell = [[DiscoverOneCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    DisModelSecond *model = [DisModelSecond new];
    model.imageNameArr = @[@"adw_icon_apcoupon_normal",@"adw_icon_coupon_normal",@"adw_icon_travel_normal",@"adw_icon_membercard_normal"];
    model.stringNameArr = @[@"红包",@"电子券",@"行程单",@"会员卡"];
    cell.model = model;
    
      return cell;
}

- (UITableViewCell *)createSecondSection:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"secondcell";
    DiscoverSecondCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    [cell removeFromSuperview];
    if (!cell) {
        cell = [[DiscoverSecondCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
  DiscoverModel *mode = [DiscoverModel new];
    if (indexPath.row ==0) {
        
        
        mode.string = @"淘宝电影";
        mode.imageName = @"adw_icon_movie_normal";
        cell.model = mode;
        
        return cell;
    }else if (indexPath.row == 1){
    
    mode.string = @"快抢";
    mode.imageName = @"adw_icon_flashsales_normal";
    cell.model = mode;
    
    return cell;
    }
    else{
        
        mode.string = @"快的打车";
        mode.imageName = @"adw_icon_taxi_normal";
        cell.model = mode;
        return cell;
    }
}

- (UITableViewCell *)createThreeSection:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"thirdcell";
    DiscoverSecondCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    [cell removeFromSuperview];
    if (!cell) {
        cell = [[DiscoverSecondCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }

    DiscoverModel *mode = [DiscoverModel new];
    mode.string = @"我的朋友";
    mode.imageName = @"adw_icon_contact_normal";
    cell.model = mode;
   
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 10;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 10;
}

-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.section) {
        case SECTION_FIRST:
            return ([UIScreen mainScreen].bounds.size.width-30*5)/4 + 40;
            break;
            case SECTION_THREE:
            case SECTION_SECOND:
            return 43;
        default:
            break;
    }
    return 0;
}
/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
