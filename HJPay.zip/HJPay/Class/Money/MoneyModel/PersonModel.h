//
//  PersonModel.h
//  HJPay
//
//  Created by ch－hj on 16/5/16.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PersonModel : NSObject
@property (nonatomic,strong) NSString *name;
@property (nonatomic,strong) NSString *imageName;
@property (nonatomic,strong) NSString *scanname;
@property (nonatomic,strong) NSString *detail;

@end
