//
//  MoneyModel.h
//  HJPay
//
//  Created by ch－hj on 16/5/17.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MoneyModel : NSObject
@property (nonatomic,strong) NSString *balance;
@property (nonatomic,strong) NSString *money;
@property (nonatomic,strong) NSString *cards;
@property (nonatomic,strong) NSString *numbers;

@end
