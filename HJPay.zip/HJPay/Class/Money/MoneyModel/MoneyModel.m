//
//  MoneyModel.m
//  HJPay
//
//  Created by ch－hj on 16/5/17.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import "MoneyModel.h"

@implementation MoneyModel

@end
