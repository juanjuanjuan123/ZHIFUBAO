//
//  MoneyController.m
//  HJPay
//
//  Created by ch－hj on 16/5/16.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import "MoneyController.h"
#import "DiscoverSecondCell.h"
#import "MoneyTableviewCell.h"
#import "MoneySecondViewCell.h"

#define    SECTION_FIRST  0
#define    SECTION_SECOND 1
#define    SECTION_THREE  2
#define    SECTION_FOURCE 3

@interface MoneyController ()

@end

@implementation MoneyController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    self.tableView.separatorColor = [UIColor lightGrayColor];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 4;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    switch (section) {
        case SECTION_FIRST:
            return 2;
            break;
        case SECTION_SECOND:
            return 3;
            break;
        case SECTION_THREE:
            return 3;
            break;
        case SECTION_FOURCE:
            return 1;
            
        default:
            break;
    }
    
    return 0;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.section) {
        case SECTION_FIRST:
           return [self creatFirstSection:tableView cellForRowAtIndexPath:indexPath];
            
            break;
        case SECTION_SECOND:
            return [self creatSecondSection:tableView cellForRowAtIndexPath:indexPath];
            break;
        case SECTION_THREE:
            return [self creatThirdSection:tableView cellForRowAtIndexPath:indexPath];
            break;
        case SECTION_FOURCE:
            return [self creatFoureSection:tableView];
        default:
            break;
    }
    
    return nil;
}

- (UITableViewCell *)creatFirstSection:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row==0) {
    static NSString *identifier = @"firstsection";
    
        
    MoneyTableviewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[MoneyTableviewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    
    PersonModel *model = [PersonModel new];
    model.scanname = @"ppc_qr";
    model.imageName = @"tmall_icon";
    model.name = @"jenney";
    model.detail = @"15681150661";
    cell.model = model;
        return cell;
    }else if(indexPath.row ==1){
        static NSString *identifier = @"section";
        MoneySecondViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [[MoneySecondViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        }
        MoneyModel *mode = [MoneyModel new];
        mode.balance = @"余额";
        mode.money = @"600.00";
        mode.cards = @"银行卡";
        mode.numbers =@"2张";
        cell.model = mode;
        
        return cell;
        
    }
    return nil;
    
}

- (UITableViewCell *)creatSecondSection:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"secondsection";
    DiscoverSecondCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[DiscoverSecondCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    
    DiscoverModel *model = [DiscoverModel new];
    if (indexPath.row == 0) {
        model.string = [NSString stringWithFormat:@"余额宝"];
        model.imageName =[NSString stringWithFormat:@"20000032Icon"];
        cell.model = model;
        return cell;
    }else if (indexPath.row ==1)
    {
        model.string = [NSString stringWithFormat:@"招财宝"];
        model.imageName =[NSString stringWithFormat:@"20000059Icon"];
        cell.model = model;
        return cell;
    }else{
        model.string = [NSString stringWithFormat:@"娱乐宝"];
        model.imageName =[NSString stringWithFormat:@"20000077Icon"];
        cell.model = model;
        return cell;
    }
    
    return nil;
    
}

- (UITableViewCell *)creatThirdSection:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"thirdsection";
    DiscoverSecondCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[DiscoverSecondCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    
    DiscoverModel *model = [DiscoverModel new];
    if (indexPath.row == 0) {
        model.string = [NSString stringWithFormat:@"芝麻信用分"];
        model.imageName =[NSString stringWithFormat:@"20000118Icon"];
        cell.model = model;
        return cell;
    }else if (indexPath.row ==1)
    {
        model.string = [NSString stringWithFormat:@"随身贷"];
        model.imageName =[NSString stringWithFormat:@"20000180Icon"];
        cell.model = model;
        return cell;
    }else{
        model.string = [NSString stringWithFormat:@"我的保障"];
        model.imageName =[NSString stringWithFormat:@"20000110Icon"];
        cell.model = model;
        return cell;
    }
    return nil;
    
}

- (UITableViewCell *)creatFoureSection:(UITableView *)tableView {
    static NSString *identifier = @"foursection";
    DiscoverSecondCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[DiscoverSecondCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    DiscoverModel *model = [DiscoverModel new];
    model.string = [NSString stringWithFormat:@"爱心捐赠"];
    model.imageName =[NSString stringWithFormat:@"09999978Icon"];
    cell.model = model;
    return cell;
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 10;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 10;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.section) {
        case SECTION_FIRST:
            if (indexPath.row==0) {
                return 70;
            }
            if (indexPath.row == 1) {
                return 43;
            }
            break;
        case SECTION_SECOND:
        case SECTION_THREE:
        case SECTION_FOURCE:
            return 43;
        default:
            break;
    }
    return 0;
}
/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */

/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
 } else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }
 }
 */

/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 */

/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
