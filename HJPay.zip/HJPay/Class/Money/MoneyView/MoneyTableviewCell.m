//
//  MoneyTableviewCell.m
//  HJPay
//
//  Created by ch－hj on 16/5/16.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import "MoneyTableviewCell.h"
@interface MoneyTableviewCell(){
    
}

@end

@implementation MoneyTableviewCell


- (instancetype )initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self setupcell];
        self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    return self;
}

- (void)setupcell{
    _iconImageView = [UIImageView new];
    _detailLabel = [UILabel new];
    _nameLabel = [UILabel new];
    _scanImageView = [UIImageView new];
    _nameLabel.textColor = [UIColor blackColor];
    _nameLabel.font = [UIFont boldSystemFontOfSize:18];
    
    _detailLabel.textColor = [UIColor blackColor];
    _detailLabel.font = [UIFont systemFontOfSize:15];
    [self.contentView addSubview:_iconImageView];
    [self.contentView addSubview:_nameLabel];
    [self.contentView addSubview:_detailLabel];
    [self.contentView addSubview:_scanImageView];
    
    
    _iconImageView.frame = CGRectMake(15, (70-55)/2, 55, 55);
    _nameLabel.frame =  CGRectMake(80, (70-55)/2, 150, 21);
    
    _detailLabel.frame =  CGRectMake(80, 28.5+10, 150, 21);

    _scanImageView.frame =  CGRectMake([UIScreen mainScreen].bounds.size.width - 70, (70-20)/2, 20, 20);

    
    
    
}
- (void) setModel:(PersonModel *)model{
    _model = model;
    _iconImageView.image = [UIImage imageNamed:model.imageName];
    _scanImageView.image= [UIImage imageNamed:model.scanname];
    _nameLabel.text = [NSString stringWithFormat:@"%@",model.name];
    _detailLabel.text = [NSString stringWithFormat:@"%@",model.detail];

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
