//
//  MoneyTableviewCell.h
//  HJPay
//
//  Created by ch－hj on 16/5/16.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PersonModel.h"

@interface MoneyTableviewCell : UITableViewCell
@property (nonatomic,strong) PersonModel *model;
@property (nonatomic,strong) UILabel *nameLabel;
@property (nonatomic,strong) UIImageView *iconImageView;
@property (nonatomic,strong) UILabel *detailLabel;
@property (nonatomic,strong) UIImageView *scanImageView;

@end
