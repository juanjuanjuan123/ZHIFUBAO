//
//  MoneySecondViewCell.m
//  HJPay
//
//  Created by ch－hj on 16/5/17.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import "MoneySecondViewCell.h"

@implementation MoneySecondViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self setupview];
    }
    return self;
}
-(void) setFrame:(CGRect)frame{
    frame.size.height -= 1;
    frame.size.width = [UIScreen mainScreen].bounds.size.width;
    [super setFrame:frame];
}

-(void)setupview{
    _label1 = [UILabel new];
    _label2 = [UILabel new];
    _label3 = [UILabel new];
    _label4 = [UILabel new];
    
    _label1.font = [UIFont boldSystemFontOfSize:16];
    _label1.textColor = [UIColor blackColor];
    _label2.font = [UIFont boldSystemFontOfSize:16];
    _label2.textColor = [UIColor blackColor];
    _label3.font = [UIFont boldSystemFontOfSize:16];
    _label3.textColor = [UIColor blackColor];
    _label4.font = [UIFont boldSystemFontOfSize:16];
    _label4.textColor = [UIColor blackColor];
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width/2, 0, 1, self.frame.size.height)];
    view.backgroundColor = [UIColor lightGrayColor];
    
    [self.contentView addSubview:_label1];
    [self.contentView addSubview:_label2];
    [self.contentView addSubview:_label3];
    [self.contentView addSubview:_label4];
    [self.contentView addSubview:view];
    
    _label1.frame = CGRectMake(15,(43 - 25)/2, 40, 25);
    _label2.frame = CGRectMake([UIScreen mainScreen].bounds.size.width/2-75,(43 - 25)/2, 60, 25);
    _label3.frame = CGRectMake([UIScreen mainScreen].bounds.size.width/2+15,(43 - 25)/2, 60, 25);
    _label4.frame = CGRectMake([UIScreen mainScreen].bounds.size.width-55,(43 - 25)/2, 40, 25);
    
    
    
    
    
    
}
-(void)setModel:(MoneyModel *)model{
    _model = model;
    _label1.text = [NSString stringWithFormat:@"%@",model.balance];
    _label2.text =[NSString stringWithFormat:@"%@",model.money];
    _label3.text = [NSString stringWithFormat:@"%@",model.cards];
    _label4.text = [NSString stringWithFormat:@"%@",model.numbers];
}
@end
