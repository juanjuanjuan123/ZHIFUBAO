//
//  MoneySecondViewCell.h
//  HJPay
//
//  Created by ch－hj on 16/5/17.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MoneyModel.h"

@interface MoneySecondViewCell : UITableViewCell
@property (nonatomic,strong) MoneyModel *model;
@property (nonatomic,strong) UILabel *label1;
@property (nonatomic,strong) UILabel *label2;
@property (nonatomic,strong) UILabel *label3;
@property (nonatomic,strong) UILabel *label4;


@end
