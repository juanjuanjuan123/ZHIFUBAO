//
//  HTabBarController.h
//  HJPay
//
//  Created by ch－hj on 16/5/16.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HTabBarController : UITabBarController

@end
