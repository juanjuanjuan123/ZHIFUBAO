//
//  HTabBarController.m
//  HJPay
//
//  Created by ch－hj on 16/5/16.
//  Copyright © 2016年 ch－hj. All rights reserved.
//

#import "HTabBarController.h"
#import "HomeController.h"
#import "DiscoverController.h"
#import "MoneyController.h"
#import "ServiceController.h"
#import "BaseNaviationController.h"

typedef NS_ENUM(NSInteger,UIType) {
    homeType   = 0,
    discoverv =1,
    frendesType  =2,
    moneyType =3,
    
};


@interface HTabBarController ()
@property(nonatomic,assign) UIType uiType;
@end

@implementation HTabBarController
UINavigationController *nav;
- (void)viewDidLoad {
    [super viewDidLoad];
    [self createRootViewController:[HomeController class] navigationControolerclass:[BaseNaviationController class] title:[NSString stringWithFormat:@"支付宝"] tabBarImageName:@"TabBar_HomeBar" uiType:0];
    
    [self createRootViewController:[ServiceController class] navigationControolerclass:[BaseNaviationController class] title:[NSString stringWithFormat:@"朋友"] tabBarImageName:@"TabBar_PublicService" uiType:2];
    
    [self createRootViewController:[DiscoverController class] navigationControolerclass:[BaseNaviationController class] title:[NSString stringWithFormat:@"发现"] tabBarImageName:@"TabBar_Discovery" uiType:1];
    
    [self createRootViewController:[MoneyController  class] navigationControolerclass:[BaseNaviationController class] title:[NSString stringWithFormat:@"我的"] tabBarImageName:@"TabBar_Assets" uiType:3];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)createRootViewController:(Class) rootViewControllerClass navigationControolerclass:(Class) navigationControolerclass title:(NSString *)title tabBarImageName:(NSString *)tabBarImageName uiType:(UIType) uiType{
    UIViewController *vc = [[rootViewControllerClass alloc]init];
    nav = [[navigationControolerclass alloc]initWithRootViewController:vc];
    
    if (uiType==homeType || uiType == moneyType) {
        [self setupNavigationBar];
       
    }else if(uiType ==1){
        [self setDiscoverNavBar];
    }else {
        [self setFrendsNavBar];
    }
    nav.title = title;
    //vc.title = title;
    nav.tabBarItem.image = [UIImage imageNamed:tabBarImageName];
    nav.tabBarItem.selectedImage = [UIImage imageNamed:[NSString stringWithFormat:@"%@_Sel", tabBarImageName]];
    [self addChildViewController:nav];
    
    
}

- (void)setupNavigationBar{
    
    UIImage *faceImage = [UIImage imageNamed:@"TabBar_Discovery"];
    UIButton *face = [UIButton buttonWithType:UIButtonTypeCustom];
    face.bounds = CGRectMake( 0, 0, faceImage.size.width, faceImage.size.height );
    [face setImage:faceImage forState:UIControlStateNormal];
    UIBarButtonItem *faceBtn = [[UIBarButtonItem alloc] initWithCustomView:face];
    faceBtn.title = [NSString stringWithFormat:@"菜单"];
    //UIBarButtonItem *item1 = [[UIBarButtonItem alloc]initWithTitle:[NSString stringWithFormat:@"菜单"] style:UIBarButtonItemStylePlain target:self action:@selector(detal)];
    [faceBtn setTitleTextAttributes:[ NSDictionary dictionaryWithObjectsAndKeys :
                                   
                                   [ UIFont fontWithName : @"Helvetica-Bold" size : 17.0 ], NSFontAttributeName ,
                                   
                                   [ UIColor greenColor ], NSForegroundColorAttributeName ,
                                   
                                   nil ]  forState:UIControlStateNormal];
    
    
       nav.navigationItem.leftBarButtonItem = faceBtn;
    
}

-(void)setDiscoverNavBar{
}

-(void)setFrendsNavBar{
}

-(void)detal{
    
}
@end
